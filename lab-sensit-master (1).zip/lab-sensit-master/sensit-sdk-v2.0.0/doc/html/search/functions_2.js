var searchData=
[
  ['ltr329_5finit',['LTR329_init',['../group__LTR329__API.html#ga435c984c5d26894fe5087dee307698f7',1,'ltr329.h']]],
  ['ltr329_5fmeasure',['LTR329_measure',['../group__LTR329__API.html#ga8951c9a424b625f2d735894e7fffcc54',1,'ltr329.h']]],
  ['ltr329_5fset_5factive_5fmode',['LTR329_set_active_mode',['../group__LTR329__API.html#gaa7ebbd9dd925be1a4c6441e2db157a1a',1,'ltr329.h']]],
  ['ltr329_5fset_5fstandby_5fmode',['LTR329_set_standby_mode',['../group__LTR329__API.html#ga95a2464ed7b25258e416ff23a9549300',1,'ltr329.h']]]
];
