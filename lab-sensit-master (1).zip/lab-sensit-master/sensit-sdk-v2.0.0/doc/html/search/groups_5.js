var searchData=
[
  ['sens_27it_20apis',['Sens&apos;it APIs',['../group__SENSIT__API.html',1,'']]],
  ['sens_27it_20error_20codes',['Sens&apos;it Error Codes',['../group__SENSIT__ERR__CODES.html',1,'']]],
  ['sensors_20address',['Sensors address',['../group__SENSOR__I2C__ADDR.html',1,'']]]
];
