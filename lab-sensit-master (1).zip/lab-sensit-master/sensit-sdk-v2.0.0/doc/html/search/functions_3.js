var searchData=
[
  ['radio_5fapi_5finit',['RADIO_API_init',['../group__RADIO__API.html#ga0a6ffeb5241f3a289ef21347777fa8ea',1,'radio_api.h']]],
  ['radio_5fapi_5fsend_5fmessage',['RADIO_API_send_message',['../group__RADIO__API.html#ga68d4194c5b5837639fbd71c9563b36fd',1,'radio_api.h']]]
];
