var searchData=
[
  ['sigfox_5frc1',['SIGFOX_RC1',['../sensit__api_8h.html#adce0751287eca928c9a31483a0c93fd9a5c08ee0ab44ccb9f04df2fff24f52ad4',1,'sensit_api.h']]],
  ['sigfox_5frc2',['SIGFOX_RC2',['../sensit__api_8h.html#adce0751287eca928c9a31483a0c93fd9ae54191f69e311a74f6c97907d9c499a1',1,'sensit_api.h']]],
  ['sigfox_5frc3c',['SIGFOX_RC3C',['../sensit__api_8h.html#adce0751287eca928c9a31483a0c93fd9a430c23ba6c6e2da971ce2d9be773b6f3',1,'sensit_api.h']]],
  ['sigfox_5frc4',['SIGFOX_RC4',['../sensit__api_8h.html#adce0751287eca928c9a31483a0c93fd9aa2ff46343844cefacb4031e101e94eab',1,'sensit_api.h']]]
];
