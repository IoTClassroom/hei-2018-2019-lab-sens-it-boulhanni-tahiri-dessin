var searchData=
[
  ['firmware_5fversion',['firmware_version',['../sensit__api_8h.html#a0269b9fb56279bb44c5f9c8bbe104c5b',1,'sensit_api.h']]]
];
