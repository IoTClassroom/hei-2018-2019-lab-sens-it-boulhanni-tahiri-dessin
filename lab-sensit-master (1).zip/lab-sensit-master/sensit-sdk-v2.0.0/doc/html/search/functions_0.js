var searchData=
[
  ['fxos8700_5fclear_5ftransient_5finterrupt',['FXOS8700_clear_transient_interrupt',['../group__FXOS8700__API.html#ga1160ef67d7d9e99fc4de3c43244a8524',1,'fxos8700.h']]],
  ['fxos8700_5finit',['FXOS8700_init',['../group__FXOS8700__API.html#ga4adb08be8412f9878b21f4c32e493458',1,'fxos8700.h']]],
  ['fxos8700_5fread_5facceleration',['FXOS8700_read_acceleration',['../group__FXOS8700__API.html#ga1e090bc15b806f549c8070df8f85a278',1,'fxos8700.h']]],
  ['fxos8700_5freset',['FXOS8700_reset',['../group__FXOS8700__API.html#ga072dc95a732ecc85761bfe3ce374adec',1,'fxos8700.h']]],
  ['fxos8700_5fset_5fstandby_5fmode',['FXOS8700_set_standby_mode',['../group__FXOS8700__API.html#ga9a1b8a0f81c6a644725458e5a10f2162',1,'fxos8700.h']]],
  ['fxos8700_5fset_5ftransient_5fmode',['FXOS8700_set_transient_mode',['../group__FXOS8700__API.html#gae57c3c4fd7ff20669d7326ebec6e25dd',1,'fxos8700.h']]]
];
